# Задание 1
# import random

# number = random.randint(1, 100)
# if number % 2 == 0:
#     print(f"Чётное число {number}!")
# else:
#     print(f"Нечётное число {number}!")


# Задание 2
# import os
# from datetime import datetime

# cur_date = datetime.now().strftime("%Y-%m-%d")
# base_dir = os.path.join(os.getcwd(), cur_date)
# os.mkdir(base_dir)

# file_path = os.path.join(base_dir, "filek.txt")
# with open(file_path, "w") as file:
#     pass
# subdir = os.path.join(base_dir, "subdir")
# os.mkdir(subdir)

# new_path = os.path.join(subdir, "empty_file.txt")
# os.rename(file_path, new_path)
# print(f"Файл перемещен в: {new_path}")
